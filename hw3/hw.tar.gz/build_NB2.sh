#!/bin/sh

python3 build_nb2.py $@
