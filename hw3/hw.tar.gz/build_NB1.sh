#!/bin/sh

python3 build_nb1.py $@
