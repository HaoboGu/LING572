#!/bin/sh

python3 svm_classify.py $@